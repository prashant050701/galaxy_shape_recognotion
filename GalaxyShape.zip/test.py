import numpy as np
import pandas as pd
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from astropy import units as u
from astropy.coordinates import SkyCoord
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
dataset = pd.read_csv("GalaxyZoo1_DR_table2.csv")
array=np.array(dataset.values)
X=array[:,3:13]
Y=array[:,13:].astype('int')
#print(X.shape)
#print(Y.ravel().shape)
X_train,X_test,Y_train,Y_test=model_selection.train_test_split(X,Y,test_size=0.2,random_state=0)
dtree_model = DecisionTreeClassifier().fit(X_train, Y_train)
dtree_predictions = dtree_model.predict([[26,0.423,0.0,0.0,0.577,0.0,0.0,0.577,0.143,0.857]])
for i in dtree_predictions:
    if(np.where(i==1)[0]==0):
        print("Spiral")
    elif(np.where(i==1)[0]==1):
        print("Elliptical")
    elif(np.where(i==1)[0]==2):
        print("Uncertain")
